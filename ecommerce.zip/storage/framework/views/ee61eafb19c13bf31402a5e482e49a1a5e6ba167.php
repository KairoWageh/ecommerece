
<?php $__env->startSection('content'); ?>
<!-- title -->
<h1><?php echo e(__('user.login')); ?></h1>
<!-- //title -->
<!-- content -->
<div class="sub-main-w3">
	<div class="bg-content-w3pvt">
		<div class="top-content-style">
			<img src="<?php echo e(asset('public/design/site/img/user.jpg')); ?>" alt="" />
		</div>
		
		<form method="post">
			<?php echo csrf_field(); ?>

			<!-- <p class="legend">Login Here<span class="fa fa-hand-o-down"></span></p> -->
			<?php if(session('error')): ?>
	    		<div class="alert alert-danger">
		    		<?php echo session('error'); ?>

		    	</div>
	    	<?php endif; ?>
	    	<?php if(count($errors->all()) > 0): ?> 
				<div class="alert alert-danger">
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			<?php endif; ?>
			<div class="input">
				<input type="email" placeholder="<?php echo e(__('user.email')); ?>" name="email" required />
				<span class="fa fa-envelope"></span>
			</div>
			<div class="input">
				<input type="password" placeholder="<?php echo e(__('user.password')); ?>" name="password" required />
				<span class="fa fa-unlock"></span>
			</div>
			<button type="submit" class="btn submit">
				<span class="fa fa-sign-in"></span>
			</button>
		</form>
		<a href="#" class="bottom-text-w3ls"><?php echo e(__('user.forgot_password')); ?></a>
	</div>
</div>
<!-- //content -->
<?php $__env->stopSection(); ?>
			
<?php echo $__env->make('site.layouts.auth_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/site/login.blade.php ENDPATH**/ ?>