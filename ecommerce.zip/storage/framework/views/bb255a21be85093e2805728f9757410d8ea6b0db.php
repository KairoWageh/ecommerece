<!-- <a href="#" class="btn btn-danger"><i class ="fa fa-trash"></i></a> -->

<button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete_admin"><i class ="fa fa-trash"></i></button>

<!-- Modal -->
<div id="delete_admin" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo e(__('admin.delete')); ?></h4>
      </div>
      <?php echo Form::open(['route' => ['admin.destroy', $id], 'method' => 'delete']); ?>

      <div class="modal-body">
      	<div class="alert alert-danger">
	        <h4>
	        	<?php echo e(__('admin.delete_record')); ?>

	        </h4>
	    </div>
      </div>
      <div class="modal-footer">
        <?php echo Form::submit(__('admin.delete'), ['class' => 'btn btn-danger']); ?>

        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('admin.close')); ?></button>
      </div>
      <?php echo Form::close(); ?>

    </div>

  </div>
</div><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/admins/btn/delete.blade.php ENDPATH**/ ?>