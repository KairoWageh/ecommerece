<div id="product_size_weight" class="tab-pane fade">
	<h3><?php echo e(__('admin.shippingInfo')); ?></h3>
	<div class="hidden shippingInfo"></div>
</div><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/products/tabs/product_size_weight.blade.php ENDPATH**/ ?>