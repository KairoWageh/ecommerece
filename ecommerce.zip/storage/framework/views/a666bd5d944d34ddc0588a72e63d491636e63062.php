
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/design/adminpanel/css/select2.min.css')); ?>">
<?php $__env->startPush('js'); ?>
<script type="text/javascript" src="<?php echo e(asset('public/design/adminpanel/js/select2.min.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('.js-example-basic-single').select2();
    });
</script>
<?php $__env->stopPush(); ?>
    <div class="box">
        <div class="box-header">
            <h3 class="box-title"><?php echo e($title); ?></h3>
        </div>
        <div class="box-body">
            <!-- <?php echo Form::open(['url' => adminURL('admin')]); ?> -->
            <?php echo Form::open(['route' => 'products.store', 'files' => true]); ?>

            <a href="#" class="btn btn-primary"><?php echo e(__('admin.save')); ?><i class="fa fa-floppy-o"></i></a>
            <a href="#" class="btn btn-success"><?php echo e(__('admin.save_and_continue')); ?><i class="fa fa-floppy-o"></i></a>
            <a href="#" class="btn btn-info"><?php echo e(__('admin.copy_product')); ?><i class="fa fa-file"></i></a>
            <a href="#" class="btn btn-danger"><?php echo e(__('admin.delete')); ?><i class="fa fa-trash"></i></a>
                <ul class="nav nav-tabs">
                    <li class="active"><a data-toggle="tab" href="#product_info"><?php echo e(__('admin.product_info')); ?><i class="fa fa-info"></i></a></li>
                    <li><a data-toggle="tab" href="#department"><?php echo e(__('admin.department')); ?><i class="fa fa-list"></i></a></li>
                    <li><a data-toggle="tab" href="#product_setting"><?php echo e(__('admin.product_setting')); ?><i class="fa fa-cog"></i></a></li>
                    <li><a data-toggle="tab" href="#product_media"><?php echo e(__('admin.product_media')); ?><i class="fa fa-photo"></i></a></li>
                    <li><a data-toggle="tab" href="#product_size_weight"><?php echo e(__('admin.shippingInfo')); ?><i class="fa fa-info-circle"></i></a></li>
                    <li><a data-toggle="tab" href="#other_data"><?php echo e(__('admin.other_data')); ?><i class="fa fa-database"></i></a></li>
                </ul>
                <div class="tab-content">
                    <?php echo $__env->make('admin.products.tabs.product_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('admin.products.tabs.department', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('admin.products.tabs.product_setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('admin.products.tabs.product_media', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('admin.products.tabs.product_size_weight', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('admin.products.tabs.other_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <hr />
                <a href="#" class="btn btn-primary"><?php echo e(__('admin.save')); ?><i class="fa fa-floppy-o"></i></a>
                <a href="#" class="btn btn-success"><?php echo e(__('admin.save_and_continue')); ?><i class="fa fa-floppy-o"></i></a>
                <a href="#" class="btn btn-info"><?php echo e(__('admin.copy_product')); ?><i class="fa fa-file"></i></a>
                <a href="#" class="btn btn-danger"><?php echo e(__('admin.delete')); ?><i class="fa fa-trash"></i></a>
                <div class="form-group">
                    <?php echo Form::label('name_ar', __('admin.name_ar')); ?>

                    <?php echo Form::text('name_ar', old('name_ar'), ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                    <?php echo Form::label('name_en', __('admin.name_en')); ?>

                    <?php echo Form::text('name_en', old('name_en'), ['class' => 'form-control']); ?>

                </div>

                <?php echo Form::submit(__('admin.add'), ['class' => 'btn btn-primary']); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/products/product.blade.php ENDPATH**/ ?>