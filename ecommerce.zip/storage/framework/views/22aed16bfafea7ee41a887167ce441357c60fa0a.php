

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="single-product col-md-4">
			<div class="product-f-image">
				<?php if($product->photo != null): ?>
					<img src="<?php echo e(Storage::url($product->photo)); ?>" alt="">
				<?php else: ?>
					<img src="<?php echo e(Storage::url($product->photo)); ?>" alt="">
				<?php endif; ?>
				<div class="product-hover">
					<a href="#" class="add-to-cart-link"><i class="fa fa-shopping-cart"></i> <?php echo e(__('user.add_to_cart')); ?></a>
					<a href="single-product.html" class="view-details-link"><i class="fa fa-link"></i> <?php echo e(__('user.see_datails')); ?></a>
				</div>
			</div>
			
			<h2><?php echo e($product->title); ?></h2>
			
			<div class="product-carousel-price">
				<ins>$<?php echo e($product->price); ?></ins> 
				<!-- <del>$100.00</del> -->
			</div> 
		</div>
        <div class="clear-fix"></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/site/single_dep.blade.php ENDPATH**/ ?>