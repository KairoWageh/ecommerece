<div id="product_info" class="tab-pane fade in active">
	<h3><?php echo e(__('admin.product_info')); ?></h3>
 	<div class="form-group">
 		<?php echo Form::label('title', __('admin.product_title')); ?>

 		<?php echo Form::text('title', $product->title, ['class' => 'form-control', 'placeholder' => __('admin.product_title')]); ?>

 	</div>
 	<div class="form-group">
 		<?php echo Form::label('content', __('admin.product_content')); ?>

 		<?php echo Form::textarea('content', $product->content, ['class' => 'form-control', 'placeholder' => __('admin.product_content')]); ?>

 	</div> 
</div><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/products/tabs/product_info.blade.php ENDPATH**/ ?>