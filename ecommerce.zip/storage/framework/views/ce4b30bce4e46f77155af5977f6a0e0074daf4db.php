
<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header">
        	<h3 class="box-title"><?php echo e($title); ?></h3>
        </div>
            <div class="box-body">
                <?php echo Form::open(['id' => 'form_data', 'url' => adminURL('admin/malls/destroy/all'), 'method' => 'delete']); ?>

                <!-- <?php echo Form::hidden('_method', 'delete'); ?> -->
                <?php echo e($dataTable->table([
                	'class' => 'dataTable table '
                	], true)); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

    <div id="multipleDelete" class="modal fade" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title"><?php echo e(__('admin.delete')); ?></h4>
          </div>
          <div class="modal-body">
            <div class="alert alert-danger">
                <div class="empty_record hidden">
                    <h4><?php echo e(__('admin.please_check_some_records')); ?></h4>    
                </div>
                <div class="not_empty_record hidden">
                    <h4><?php echo e(__('admin.ask_delete_item')); ?><span class="record_count"></span> </h4>
                </div>
                
            </div>
          </div>
          <div class="modal-footer">
            <div class="empty_record hidden">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('admin.close')); ?></button>
            </div>
            <div class="not_empty_record hidden">
                <input type="submit" name="delete_all" value="<?php echo e(__('admin.yes')); ?>" class="btn btn-danger delete_all">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('admin.no')); ?></button>
            </div>
          </div>
        </div>

      </div>
    </div>

<?php $__env->startPush('js'); ?>
<?php echo e($dataTable->scripts()); ?>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/malls/index.blade.php ENDPATH**/ ?>