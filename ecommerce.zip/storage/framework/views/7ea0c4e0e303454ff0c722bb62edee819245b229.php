

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	<div class="col-md-4">
            <div class="product-f-image" style="height: 50%; width: 50%">
                <img src="<?php echo e(Storage::url($department->icon)); ?>" alt="department_icon">
            </div>
            <?php if(app()->getLocale() == 'ar'): ?>
            	<h4><a href="departments/<?php echo e($department->department_name_ar); ?>" style="text-decoration: none;"> <?php echo e($department->department_name_ar); ?></a></h4>
            <?php else: ?>
            	<h4><a href="departments/<?php echo e($department->department_name_en); ?>" style="text-decoration: none;"> <?php echo e($department->department_name_en); ?></a></h4>
            <?php endif; ?>                               
        </div>
    	<div class="clear-fix"></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/site/departments.blade.php ENDPATH**/ ?>