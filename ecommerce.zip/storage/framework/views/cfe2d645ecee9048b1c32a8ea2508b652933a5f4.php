<?php $__env->startPush('js'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/design/adminpanel/css/dropzone.min.css')); ?>">
<script type="text/javascript" src="<?php echo e(asset('public/design/adminpanel/js/dropzone.min.js')); ?>"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$('#mainPhoto').dropzone({
			url: "<?php echo e(adminURL('/ecommerce/public/admin/update/image/'.$product->id)); ?>",
			paramName: 'file',
			uploadMultiple: false,
			maxFiles: 1,
			maxFilessize: 3, //MB
			acceptedFiles: 'image/*',
			dictDefaultMessage: "<?php echo e(__('admin.mainPhoto')); ?>",
			dictRemoveFile: "<?php echo e(__('admin.delete')); ?>",
			params: {
				_token: '<?php echo e(csrf_token()); ?>'
			},
			addRemoveLinks: true,
			removedfile: function(file){
				$.ajax({
					dataType: 'json',
					type: 'post',
					url: "<?php echo e(adminURL('/ecommerce/public/admin/delete/product/image/'.$product->id)); ?>",
					data: {_token: '<?php echo e(csrf_token()); ?>'}
				});
				var fmock;
				return (fmock = file.previewElement) != null ? fmock.parentNode.removeChild(file.previewElement) : void 0;
			},
			init: function(){
				<?php if(!empty($product->photo)): ?>
					var mock = {name: '<?php echo e($product->title); ?>', size: '', type: ''};
					this.emit('addedfile', mock);
					this.options.thumbnail.call(this, mock, '<?php echo e(url("storage/".$product->photo)); ?>');
					$('.dz-progress').remove();
				<?php endif; ?>
				this.on('sending', function(file, xhr, formData){
					formData.append('fid', '');
					file.fid = '';
				});

				this.on('success', function(file, response){
					file.fid = response.id;
				})
			}
		});


		$('#dropzonefileupload').dropzone({
			url: "<?php echo e(adminURL('/ecommerce/public/admin/upload/image/'.$product->id)); ?>",
			paramName: 'file',
			uploadMultiple: false,
			maxFiles: 15,
			maxFilessize: 2, //MB
			acceptedFiles: 'image/*',
			dictDefaultMessage: "<?php echo e(__('admin.uploadProductMedia')); ?>",
			dictRemoveFile: "<?php echo e(__('admin.delete')); ?>",
			params: {
				_token: '<?php echo e(csrf_token()); ?>'
			},
			addRemoveLinks: true,
			removedfile: function(file){
				$.ajax({
					dataType: 'json',
					type: 'post',
					url: "<?php echo e(adminURL('/ecommerce/public/admin/delete/image')); ?>",
					data: {_token: '<?php echo e(csrf_token()); ?>', id: file.fid}
				});
				var fmock;
				return (fmock = file.previewElement) != null ? fmock.parentNode.removeChild(file.previewElement) : void 0;
			},
			init: function(){
				<?php $__currentLoopData = $product->files()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					var mock = {name: '<?php echo e($file->name); ?>', fid: '<?php echo e($file->id); ?>', size: '<?php echo e($file->size); ?>', type: '<?php echo e($file->mime_type); ?>'};
					this.emit('addedfile', mock);
					//this.options.thumbnail.call(this, mock, '<?php echo e(url("storage/".$file->full_file)); ?>');
					this.options.thumbnail.call(this, mock, '<?php echo e(Storage::url($file->full_file)); ?>');
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				this.on('sending', function(file, xhr, formData){
					formData.append('fid', '');
					file.fid = '';
				});

				this.on('success', function(file, response){
					file.fid = response.id;
				})
			}
		});
	});
</script>
<style type="text/css">
	.dz-image img{
		width: 100px;
		height: 100px;
	}
</style>
<?php $__env->stopPush(); ?>
<div id="product_media" class="tab-pane fade">
	<h3><?php echo e(__('admin.product_media')); ?></h3>
	<hr />
	<center><h3><?php echo e(__('admin.mainPhoto')); ?></h3></center>
	<div class="dropzone" id="mainPhoto"></div>
	<hr />
	<center><h3><?php echo e(__('admin.photos')); ?></h3></center>
	<div class="dropzone" id="dropzonefileupload"></div>
</div><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/products/tabs/product_media.blade.php ENDPATH**/ ?>