<div id="other_data" class="tab-pane fade">
	<h3>Menu 1</h3>
	<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
</div><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/products/tabs/other_data.blade.php ENDPATH**/ ?>