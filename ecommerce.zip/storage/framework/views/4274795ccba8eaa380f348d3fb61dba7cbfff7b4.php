
<?php $__env->startSection('content'); ?>
	<div class="login-head">
		<h1><?php echo e(__('admin.login')); ?></h1>
	</div>
	<div class="login-block">
		<form method="post">
			<?php echo csrf_field(); ?>

			<input type="text" name="email" placeholder="<?php echo e(__('admin.email')); ?>" required="">
			<input type="password" name="password" class="lock" placeholder="<?php echo e(__('admin.password')); ?>">
			<div class="forgot-top-grids">
				<div class="forgot-grid">
					<ul>
						<li>
							<input type="checkbox" id="brand1" name="rememberme" value="1">
							<label for="brand1"><span></span>Remember me</label>
						</li>
					</ul>
				</div>
				<div class="forgot">
					<a href="<?php echo e(url('admin/forgot/password')); ?>"><?php echo e(__('admin.forgot_password')); ?></a>
				</div>
				<div class="clearfix"> </div>
			</div>
			<input type="submit" name="Sign In" value="Login">	
			<!-- <h3>Not a member?<a href="signup.html"> Sign up now</a></h3>				 -->
			<h2>or login with</h2>
			<div class="login-icons">
				<ul>
					<li><a href="#" class="facebook"><i class="fa fa-facebook"></i></a></li>
					<li><a href="#" class="twitter"><i class="fa fa-twitter"></i></a></li>
					<li><a href="#" class="google"><i class="fa fa-google-plus"></i></a></li>						
				</ul>
			</div>
		</form>
		<!-- <h5><a href="<?php echo e(route('home')); ?>">Go Back to Home</a></h5> -->
	</div>
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('admin.layouts.auth_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/login.blade.php ENDPATH**/ ?>