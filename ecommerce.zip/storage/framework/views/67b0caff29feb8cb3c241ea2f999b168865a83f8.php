
<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header">
            <h3 class="box-title"><?php echo e($title); ?></h3>
        </div>
        <div class="box-body">
            <!-- <?php echo Form::open(['url' => adminURL('admin')]); ?> -->
            <?php echo Form::open(['route' => ['colors.update', $color->id], 'method' => 'put', 'files' => true]); ?>

                <div class="form-group">
                    <?php echo Form::label('name_ar', __('admin.name_ar')); ?>

                    <?php echo Form::text('name_ar', old('name_ar', $color->name_ar), ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                    <?php echo Form::label('name_en', __('admin.name_en')); ?>

                    <?php echo Form::text('name_en', old('name_en', $color->name_en), ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                    <?php echo Form::label('color', __('admin.color')); ?>

                    <?php echo Form::color('color', old('color', $color->color), ['class' => 'form-control']); ?>

                </div>
                <?php echo Form::submit(__('admin.edit'), ['class' => 'btn btn-primary']); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
        </div>
    </div>



<!--  -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/colors/edit.blade.php ENDPATH**/ ?>