<?php $__env->startPush('js'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $('#jstree').jstree({
            "core" : {
                'data' : <?php echo load_department($product->department_id); ?>,
                "themes" : {
                  "variant" : "large"
                }
              },
              "checkbox" : {
                  "keep_selected_style" : true
              },
              "plugins" : ["wholerow"]
        });
    });
    $('#jstree').on('changed.jstree', function(e, data){
        var i, j, r = [];
        var name = [];
        for(i=0, j=data.selected.length; i<j; i++){
            r.push(data.instance.get_node(data.selected[i]).id);
            //name.push(data.instance.get_node(data.selected[i]).text);
        }
        var department_id = r.join(', ');
        $('.department_id').val(department_id);

        $.ajax({
          url: "<?php echo e(adminURL('load/shippingInfo')); ?>",
          dataType: "html",
          type: "post",
          data: {_token: '<?php echo e(csrf_token()); ?>', department_id: department_id},
          success: function(data){
            $('.shippingInfo').html(data);
          }, error: function(){
            console.log('error');
          }
        });
   });
</script>
<?php $__env->stopPush(); ?>
<div id="department" class="tab-pane fade">
	<h3><?php echo e(__('admin.department')); ?></h3>
	<div id="jstree"></div>
  <input type="hidden" name="department_id" class="department_id">
</div><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/products/tabs/department.blade.php ENDPATH**/ ?>