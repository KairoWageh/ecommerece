</div>
<!--inner block end here-->
<!--copy rights start here-->
<div class="copyrights">
	 <p>© 2016 Shoppy. All Rights Reserved | Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
</div>	
<!--COPY rights end here-->
</div>
</div>
<!--slider menu-->
    <div class="sidebar-menu">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
			      <!--<img id="logo" src="" alt="Logo"/>--> 
			  </a> </div>		  
		    <div class="menu">
		      <ul id="menu" >
		        <li id="menu-home" >
		        	<a href="<?php echo e(route('home')); ?>">
		        		<i class="fa fa-tachometer"></i>
		        		<span><?php echo e(__('admin.dashboard')); ?></span>
		        		<?php if(Session::get('lang') == 'en'): ?>
		        			<span class="fa fa-angle-right" style="float: right"></span>
		        		<?php else: ?>
		        			<span class="fa fa-angle-left" style="float: left"></span>
		        		<?php endif; ?>
		        	</a>
		        	<!-- <ul>
			            <li><a href="<?php echo e(route('home')); ?>"><?php echo e(__('admin.dashboard')); ?></a></li>
			            <li><a href="<?php echo e(route('admin.settings')); ?>"><?php echo e(__('admin.settings')); ?></a></li>
		          </ul> -->
		        </li>
		        <li>
		        	<a href="#">
		        		<i class="fa fa-users"></i>
		        		<span><?php echo e(__('admin.adminsAccounts')); ?></span>
		        		<?php if(Session::get('lang') == 'en'): ?>
		        			<span class="fa fa-angle-right" style="float: right"></span>
		        		<?php else: ?>
		        			<span class="fa fa-angle-left" style="float: left"></span>
		        		<?php endif; ?>
		        	</a>
		          <ul>
		            <li><a href="<?php echo e(route('admin.index')); ?>"><?php echo e(__('admin.adminsAccounts')); ?></a></li>
		            <li><a href="<?php echo e(route('admin.create')); ?>"><?php echo e(__('admin.addNewAdmin')); ?></a></li>
		          </ul>
		        </li>
		        <li>
		        	<a href="#">
		        		<i class="fa fa-users"></i>
		        		<span><?php echo e(__('admin.usersAccounts')); ?></span>
		        		<?php if(Session::get('lang') == 'en'): ?>
		        			<span class="fa fa-angle-right" style="float: right"></span>
		        		<?php else: ?>
		        			<span class="fa fa-angle-left" style="float: left"></span>
		        		<?php endif; ?>
		        	</a>
		          <ul>
		            <li><a href="<?php echo e(route('users.index')); ?>"><?php echo e(__('admin.usersAccounts')); ?></a></li>
		            <li><a href="<?php echo e(route('users.index', ['level' => 'user'])); ?>"><?php echo e(__('admin.user')); ?></a></li>
		            <li><a href="<?php echo e(route('users.index', ['level' => 'vendor'])); ?>"><?php echo e(__('admin.vendor')); ?></a></li>
		            <li><a href="<?php echo e(route('users.index', ['level' => 'company'])); ?>"><?php echo e(__('admin.company')); ?></a></li>
		            <li><a href="<?php echo e(route('users.create')); ?>"><?php echo e(__('admin.addNewUser')); ?></a></li>
		          </ul>
		        </li>
		        <!-- countries li -->
		        <li>
		        	<a href="#">
		        		<i class="fa fa-flag"></i>
		        		<span><?php echo e(__('admin.countries')); ?></span>
		        		<?php if(Session::get('lang') == 'en'): ?>
		        			<span class="fa fa-angle-right" style="float: right"></span>
		        		<?php else: ?>
		        			<span class="fa fa-angle-left" style="float: left"></span>
		        		<?php endif; ?>
		        	</a>
		          <ul>
		            <li><a href="<?php echo e(route('countries.index')); ?>"><?php echo e(__('admin.countries')); ?></a></li>
		            <li><a href="<?php echo e(route('countries.create')); ?>"><?php echo e(__('admin.add')); ?></a></li>
		          </ul>
		        </li>
		        <!--// countries li -->

		        <!-- cities li -->
		        <li>
		        	<a href="#">
		        		<i class="fa fa-flag"></i>
		        		<span><?php echo e(__('admin.cities')); ?></span>
		        		<?php if(Session::get('lang') == 'en'): ?>
		        			<span class="fa fa-angle-right" style="float: right"></span>
		        		<?php else: ?>
		        			<span class="fa fa-angle-left" style="float: left"></span>
		        		<?php endif; ?>
		        	</a>
		          <ul>
		            <li><a href="<?php echo e(route('cities.index')); ?>"><?php echo e(__('admin.cities')); ?></a></li>
		            <li><a href="<?php echo e(route('cities.create')); ?>"><?php echo e(__('admin.add')); ?></a></li>
		          </ul>
		        </li>
		        <!--// cities li -->

		        <!-- states li -->
		        <li>
		        	<a href="#">
		        		<i class="fa fa-flag"></i>
		        		<span><?php echo e(__('admin.states')); ?></span>
		        		<?php if(Session::get('lang') == 'en'): ?>
		        			<span class="fa fa-angle-right" style="float: right"></span>
		        		<?php else: ?>
		        			<span class="fa fa-angle-left" style="float: left"></span>
		        		<?php endif; ?>
		        	</a>
		          <ul>
		            <li><a href="<?php echo e(route('states.index')); ?>"><?php echo e(__('admin.states')); ?></a></li>
		            <li><a href="<?php echo e(route('states.create')); ?>"><?php echo e(__('admin.add')); ?></a></li>
		          </ul>
		        </li>
		        <!--// states li -->

		        <!-- departments li -->
		        <li>
		        	<a href="#">
		        		<i class="fa fa-list-alt"></i>
		        		<span><?php echo e(__('admin.departments')); ?></span>
		        		<?php if(Session::get('lang') == 'en'): ?>
		        			<span class="fa fa-angle-right" style="float: right"></span>
		        		<?php else: ?>
		        			<span class="fa fa-angle-left" style="float: left"></span>
		        		<?php endif; ?>
		        	</a>
		          <ul>
		            <li><a href="<?php echo e(route('departments.index')); ?>"><?php echo e(__('admin.departments')); ?></a></li>
		            <li><a href="<?php echo e(route('departments.create')); ?>"><?php echo e(__('admin.add')); ?></a></li>
		          </ul>
		        </li>
		        <!--// departments li -->

		        <!-- trademarks li -->
		        <li>
		        	<a href="#">
		        		<i class="fa fa-cube"></i>
		        		<span><?php echo e(__('admin.trademarks')); ?></span>
		        		<?php if(Session::get('lang') == 'en'): ?>
		        			<span class="fa fa-angle-right" style="float: right"></span>
		        		<?php else: ?>
		        			<span class="fa fa-angle-left" style="float: left"></span>
		        		<?php endif; ?>
		        	</a>
		          <ul>
		            <li><a href="<?php echo e(route('trademarks.index')); ?>"><?php echo e(__('admin.trademarks')); ?></a></li>
		            <li><a href="<?php echo e(route('trademarks.create')); ?>"><?php echo e(__('admin.add')); ?></a></li>
		          </ul>
		        </li>
		        <!--// trademarks li -->

		        <!-- manufacturers li -->
		        <li>
		        	<a href="#">
		        		<i class="fa fa-user"></i>
		        		<span><?php echo e(__('admin.manufacturers')); ?></span>
		        		<?php if(Session::get('lang') == 'en'): ?>
		        			<span class="fa fa-angle-right" style="float: right"></span>
		        		<?php else: ?>
		        			<span class="fa fa-angle-left" style="float: left"></span>
		        		<?php endif; ?>
		        	</a>
		          <ul>
		            <li><a href="<?php echo e(route('manufacturers.index')); ?>"><?php echo e(__('admin.manufacturers')); ?></a></li>
		            <li><a href="<?php echo e(route('manufacturers.create')); ?>"><?php echo e(__('admin.add')); ?></a></li>
		          </ul>
		        </li>
		        <!--// manufacturers li -->

		        <!-- shippingCompanies li -->
		        <li>
		        	<a href="#">
		        		<i class="fa fa-truck"></i>
		        		<span><?php echo e(__('admin.shippingCompanies')); ?></span>
		        		<?php if(Session::get('lang') == 'en'): ?>
		        			<span class="fa fa-angle-right" style="float: right"></span>
		        		<?php else: ?>
		        			<span class="fa fa-angle-left" style="float: left"></span>
		        		<?php endif; ?>
		        	</a>
		          <ul>
		            <li><a href="<?php echo e(route('shippingCompanies.index')); ?>"><?php echo e(__('admin.shippingCompanies')); ?></a></li>
		            <li><a href="<?php echo e(route('shippingCompanies.create')); ?>"><?php echo e(__('admin.add')); ?></a></li>
		          </ul>
		        </li>
		        <!--// shippingCompanies li -->

		        <!-- malls li -->
		        <li>
		        	<a href="#">
		        		<i class="fa fa-building"></i>
		        		<span><?php echo e(__('admin.malls')); ?></span>
		        		<?php if(Session::get('lang') == 'en'): ?>
		        			<span class="fa fa-angle-right" style="float: right"></span>
		        		<?php else: ?>
		        			<span class="fa fa-angle-left" style="float: left"></span>
		        		<?php endif; ?>
		        	</a>
		          <ul>
		            <li><a href="<?php echo e(route('malls.index')); ?>"><?php echo e(__('admin.malls')); ?></a></li>
		            <li><a href="<?php echo e(route('malls.create')); ?>"><?php echo e(__('admin.add')); ?></a></li>
		          </ul>
		        </li>
		        <!--// malls li -->

		        <!-- colors li -->
		        <li>
		        	<a href="#">
		        		<i class="fa fa-paint-brush"></i>
		        		<span><?php echo e(__('admin.colors')); ?></span>
		        		<?php if(Session::get('lang') == 'en'): ?>
		        			<span class="fa fa-angle-right" style="float: right"></span>
		        		<?php else: ?>
		        			<span class="fa fa-angle-left" style="float: left"></span>
		        		<?php endif; ?>
		        	</a>
		          <ul>
		            <li><a href="<?php echo e(route('colors.index')); ?>"><?php echo e(__('admin.colors')); ?></a></li>
		            <li><a href="<?php echo e(route('colors.create')); ?>"><?php echo e(__('admin.add')); ?></a></li>
		          </ul>
		        </li>
		        <!--// colors li -->

		        <!-- sizes li -->
		        <li>
		        	<a href="#">
		        		<i class="fa fa-info-circle"></i>
		        		<span><?php echo e(__('admin.sizes')); ?></span>
		        		<?php if(Session::get('lang') == 'en'): ?>
		        			<span class="fa fa-angle-right" style="float: right"></span>
		        		<?php else: ?>
		        			<span class="fa fa-angle-left" style="float: left"></span>
		        		<?php endif; ?>
		        	</a>
		          <ul>
		            <li><a href="<?php echo e(route('sizes.index')); ?>"><?php echo e(__('admin.sizes')); ?></a></li>
		            <li><a href="<?php echo e(route('sizes.create')); ?>"><?php echo e(__('admin.add')); ?></a></li>
		          </ul>
		        </li>
		        <!--// sizes li -->

		        <!-- weights li -->
		        <li>
		        	<a href="#">
		        		<i class="fa fa-balance-scale"></i>
		        		<span><?php echo e(__('admin.weights')); ?></span>
		        		<?php if(Session::get('lang') == 'en'): ?>
		        			<span class="fa fa-angle-right" style="float: right"></span>
		        		<?php else: ?>
		        			<span class="fa fa-angle-left" style="float: left"></span>
		        		<?php endif; ?>
		        	</a>
		          <ul>
		            <li><a href="<?php echo e(route('weights.index')); ?>"><?php echo e(__('admin.weights')); ?></a></li>
		            <li><a href="<?php echo e(route('weights.create')); ?>"><?php echo e(__('admin.add')); ?></a></li>
		          </ul>
		        </li>
		        <!--// weights li -->

		        <!-- products li -->
		        <li>
		        	<a href="#">
		        		<i class="fa fa-tag"></i>
		        		<span><?php echo e(__('admin.products')); ?></span>
		        		<?php if(Session::get('lang') == 'en'): ?>
		        			<span class="fa fa-angle-right" style="float: right"></span>
		        		<?php else: ?>
		        			<span class="fa fa-angle-left" style="float: left"></span>
		        		<?php endif; ?>
		        	</a>
		          <ul>
		            <li><a href="<?php echo e(route('products.index')); ?>"><?php echo e(__('admin.products')); ?></a></li>
		            <li><a href="<?php echo e(route('products.create')); ?>"><?php echo e(__('admin.add')); ?></a></li>
		          </ul>
		        </li>
		        <!--// products li -->

		      </ul>
		    </div>
	 </div>
	<div class="clearfix"> </div>
<!-- </div> -->
<!--slide bar menu end here-->
<?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/layouts/menu.blade.php ENDPATH**/ ?>