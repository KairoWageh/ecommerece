<div id="product_size_weight" class="tab-pane fade">
	<h3>{{__('admin.shippingInfo')}}</h3>
	<div class="hidden shippingInfo"></div>
</div>