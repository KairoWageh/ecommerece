@include('admin.layouts.header')
@include('admin.layouts.navbar')
@include('admin.layouts.message')

@yield('content')


@include('admin.layouts.menu')

@include('admin.layouts.footer')