@include('site.layouts.header')
@include('site.layouts.navbar')
@include('site.layouts.menu')
@include('site.layouts.message')

@yield('content')

@include('site.layouts.footer')