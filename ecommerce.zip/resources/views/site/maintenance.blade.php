@extends('site.index')

@section('content')

	{!! setting()->message_maintenance !!}
@endsection