@extends('site.index')

@section('content')
<div class="container">
    @foreach($products as $product)
        <div class="single-product col-md-4">
			<div class="product-f-image">
				@if($product->photo != null)
					<img src="{{Storage::url($product->photo)}}" alt="">
				@else
					<img src="{{Storage::url($product->photo)}}" alt="">
				@endif
				<div class="product-hover">
					<a href="#" class="add-to-cart-link"><i class="fa fa-shopping-cart"></i> {{__('user.add_to_cart')}}</a>
					<a href="single-product.html" class="view-details-link"><i class="fa fa-link"></i> {{__('user.see_datails')}}</a>
				</div>
			</div>
			
			<h2>{{$product->title}}</h2>
			
			<div class="product-carousel-price">
				<ins>${{$product->price}}</ins> 
				<!-- <del>$100.00</del> -->
			</div> 
		</div>
        <div class="clear-fix"></div>
    @endforeach
</div>
@endsection