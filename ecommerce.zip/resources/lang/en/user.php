<?php

return [
	"login"                            => "Login",
    "logout"                           => "Logout",
    "language"                         => "Language",
    "email"                            => "Email",
    "password"                         => "Password",
    "wrong_creditionals"               => "Email or password is incorrect.",
    "forgot_password"                  => "Forgot password?",
    "my_account"                       => "My Account",
    "wishlist"                         => "Wishlist",
    "my_cart"                          => "My Cart",
    "checkout"                         => "Checkout",
    "home"                             => "Home",
    "shop_page"                        => "Shop page",
    "departments"                      => "Departments",
    "add_to_cart"                      => "Add to cart",
    "see_datails"                      => "See datails",
    

];